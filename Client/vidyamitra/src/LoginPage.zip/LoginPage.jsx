import React from "react";

export default function LoginPage() {
  return (
    <div className="min-h-screen flex flex-col justify-center items-center bg-gradient-to-b from-green-50 to-white">
      {/* Heading */}
      <h1 className="text-lg font-semibold">Welcome to EduRural</h1>
      <p className="text-gray-500 mb-6">Sign in to your teacher account</p>

      {/* Form */}
      <div className="bg-white p-8 rounded-xl shadow-lg w-full max-w-md">
        <h2 className="text-center text-lg font-medium mb-4">Sign In</h2>
        <p className="text-center text-gray-500 mb-6">
          Enter your email and password to access your dashboard
        </p>

        <form>
          <label className="block mb-2 text-gray-700">Email Address</label>
          <input
            type="email"
            placeholder="teacher@school.edu"
            className="w-full border rounded-lg p-3 mb-4 focus:outline-none focus:ring-2 focus:ring-green-500"
          />

          <label className="block mb-2 text-gray-700">Password</label>
          <input
            type="password"
            placeholder="Enter your password"
            className="w-full border rounded-lg p-3 mb-2 focus:outline-none focus:ring-2 focus:ring-green-500"
          />

          <div className="flex justify-between items-center mb-4">
            <label className="flex items-center text-gray-600">
              <input type="checkbox" className="mr-2" /> Remember me
            </label>
            <a href="#" className="text-green-600 text-sm hover:underline">
              Forgot password?
            </a>
          </div>

          <button
            type="submit"
            className="w-full bg-green-600 text-white p-3 rounded-lg hover:bg-green-700 transition"
          >
            Sign In
          </button>
        </form>

        <p className="text-center text-gray-600 mt-6">
          Don’t have an account?{" "}
          <a href="#" className="text-green-600 hover:underline">
            Sign up here
          </a>
        </p>
      </div>

      {/* Footer */}
      <p className="text-center text-gray-500 mt-6 text-sm">
        EduRural Teacher Management System
        <br />
        <span className="text-gray-400">
          Empowering rural education through technology
        </span>
      </p>
    </div>
  );
}